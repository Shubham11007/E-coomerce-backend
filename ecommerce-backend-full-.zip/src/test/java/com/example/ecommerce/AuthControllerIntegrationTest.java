package com.example.ecommerce;

import com.example.ecommerce.dto.AuthRequest;
import com.example.ecommerce.dto.AuthResponse;
import com.example.ecommerce.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.*;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class AuthControllerIntegrationTest {

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate restTemplate;

    @Autowired
    private UserRepository userRepository;

    @Test
    void registerAndLoginFlow() {
        // register
        AuthRequest req = new AuthRequest();
        req.setEmail("inttest@example.com");
        req.setPassword("password123");
        req.setFullName("Integration Test");

        ResponseEntity<String> regResp = restTemplate.postForEntity(createUrl("/api/auth/register"), req, String.class);
        assertEquals(HttpStatus.OK, regResp.getStatusCode());

        // login
        AuthRequest login = new AuthRequest();
        login.setEmail("inttest@example.com");
        login.setPassword("password123");

        ResponseEntity<AuthResponse> loginResp = restTemplate.postForEntity(createUrl("/api/auth/login"), login, AuthResponse.class);
        assertEquals(HttpStatus.OK, loginResp.getStatusCode());
        assertNotNull(loginResp.getBody().getToken());
    }

    private String createUrl(String path) { return "http://localhost:" + port + path; }
}