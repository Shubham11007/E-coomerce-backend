package com.example.ecommerce;

import com.example.ecommerce.config.JwtUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class JwtUtilsTest {

    @Autowired
    private JwtUtils jwtUtils;

    @Test
    void generateAndValidateToken() {
        String token = jwtUtils.generateToken("testuser@example.com");
        assertNotNull(token);
        assertTrue(jwtUtils.validateJwtToken(token));
        assertEquals("testuser@example.com", jwtUtils.getUserNameFromJwtToken(token));
    }
}