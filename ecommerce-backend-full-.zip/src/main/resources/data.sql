INSERT INTO books (id, title, author, category, price, rating, stock, description) VALUES
(1, 'Clean Code', 'Robert C. Martin', 'Programming', 399.0, 4.7, 10, 'Best practices'),
(2, 'Effective Java', 'Joshua Bloch', 'Programming', 499.0, 4.8, 5, 'Java best practices'),
(3, 'Pragmatic Programmer', 'Andy Hunt', 'Programming', 350.0, 4.6, 7, 'Software craftsmanship');