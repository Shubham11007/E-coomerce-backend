package com.example.ecommerce.controller;

import com.example.ecommerce.entity.Book;
import com.example.ecommerce.entity.Cart;
import com.example.ecommerce.entity.CartItem;
import com.example.ecommerce.entity.User;
import com.example.ecommerce.repository.BookRepository;
import com.example.ecommerce.repository.CartRepository;
import com.example.ecommerce.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BookRepository bookRepository;

    @PostMapping("/add")
    public String addToCart(Authentication auth, @RequestParam Long bookId, @RequestParam int qty) {
        String email = auth.getName();
        User user = userRepository.findByEmail(email).orElseThrow();
        Cart cart = cartRepository.findById(user.getId()).orElseGet(() -> {
            Cart c = new Cart();
            c.setUser(user);
            return c;
        });
        Book book = bookRepository.findById(bookId).orElseThrow();
        CartItem item = new CartItem();
        item.setBook(book);
        item.setQuantity(qty);
        cart.getItems().add(item);
        cartRepository.save(cart);
        return "Added";
    }

    @GetMapping
    public Cart getCart(Authentication auth) {
        String email = auth.getName();
        User user = userRepository.findByEmail(email).orElseThrow();
        return cartRepository.findById(user.getId()).orElse(new Cart());
    }
}
