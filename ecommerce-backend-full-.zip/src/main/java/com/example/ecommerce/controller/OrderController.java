package com.example.ecommerce.controller;

import com.example.ecommerce.entity.*;
import com.example.ecommerce.repository.BookRepository;
import com.example.ecommerce.repository.CartRepository;
import com.example.ecommerce.repository.OrderRepository;
import com.example.ecommerce.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/checkout")
    @Transactional
    public Order checkout(Authentication auth) {
        String email = auth.getName();
        User user = userRepository.findByEmail(email).orElseThrow();
        Cart cart = cartRepository.findById(user.getId()).orElseThrow();

        Order order = new Order();
        order.setUser(user);
        double total = 0;
        for (CartItem ci : cart.getItems()) {
            Book book = bookRepository.findById(ci.getBook().getId()).orElseThrow();
            if (book.getStock() < ci.getQuantity()) throw new RuntimeException("Insufficient stock for " + book.getTitle());
            book.setStock(book.getStock() - ci.getQuantity());
            bookRepository.save(book);
            OrderItem oi = new OrderItem();
            oi.setBook(book);
            oi.setPrice(book.getPrice());
            oi.setQuantity(ci.getQuantity());
            order.getItems().add(oi);
            total += oi.getPrice() * oi.getQuantity();
        }
        order.setTotalAmount(total);
        order.setStatus("COMPLETED");
        orderRepository.save(order);
        cart.getItems().clear();
        cartRepository.save(cart);
        return order;
    }
}
