package com.example.ecommerce.controller;

import com.example.ecommerce.entity.Book;
import com.example.ecommerce.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/books")
public class BookController {

    @Autowired
    private BookRepository bookRepository;

    @GetMapping("/search")
    public Page<Book> search(@RequestParam(required = false) String q,
                             @RequestParam(defaultValue = "0") int page,
                             @RequestParam(defaultValue = "10") int size) {
        Pageable pageable = PageRequest.of(page, size);
        if (q == null || q.isBlank()) return bookRepository.findAll(pageable);
        return bookRepository.findByTitleContainingIgnoreCase(q, pageable);
    }

    @PostMapping
    public Book add(@RequestBody Book b) { return bookRepository.save(b); }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) { bookRepository.deleteById(id); }
}
