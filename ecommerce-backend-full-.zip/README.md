
## Extras added
- `src/main/resources/data.sql` : sample data to preload books.
- `docs/postman_collection.json` : Postman collection for quick testing.
- Swagger/OpenAPI UI available at `/swagger-ui.html` (springdoc) after running the app.
- Unit tests and integration tests under `src/test/java` (uses H2 in-memory DB).
- `src/test/resources/application-test.properties` configures H2 for tests.
